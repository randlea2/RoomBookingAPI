class Rooms():
	
	def __init__(self): 
		self.rooms() 
		
	def rooms(self):
		self.roomDict = {} 
		roomFileLines = open(roomFile, "r").readlines()
		for room in roomFileLines:
			name = room.split()[0]
			capacity = room.split()[1] 
			self.roomDict[name] = {}
			self.roomDict[name]["capactiy"] = capacity 
			self.roomDict[name]["name"] = name 
		return self.roomDict
		
	def get(self):
		return self.roomDict
