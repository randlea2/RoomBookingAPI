import requests, time, random, sqlite3

class Client():
	
	def __init__(self):
		## uri to send request
		#self.uri = "http://127.0.0.1:5000/timetable/book" 
		self.uri = "http://127.0.0.1:5000/timetable/book"
	def getRandomDay(self): 
		## return a random day
		days =  ["Mon","Tues","Wed","Thurs","Fri"]; 
		index = random.randint(0,len(days)-1)
		return days[index] 
	
	def getRandomTime(self):
		times = ["08:00","09:00","10:00" , "11:00","12:00" , "13:00", "14:00","15:00" ,"16:00" ,"17:00"]
		index = random.randint(0,len(times)-1)
		return times[index]
		
	def getRandomEvent(self):
		events = ["Lab", "Lecture", "Tutorial"]
		index  = random.randint(0,len(events)-1)
		return events[index]


	def getRandomRoom(self):
		rooms = [] 
		with sqlite3.connect('booking.db') as connection:
			cursor = connection.cursor()
			result = cursor.execute("SELECT * FROM rooms").fetchall()
			for room in result:
				rooms.append(room[0])
		index  = random.randint(0,len(rooms)-1)
		return rooms[index]
		
	def testMode(self, requestNumber):
		print(requestNumber)
		logHTML = "<h2> Test Mode </h2>"
		logHTML += "<p> Generating {} randomly generated request.......</p>".format(requestNumber) 
		log = "Generating {} randomly generated request.......\n".format(requestNumber) 
		startTime = time.time()
		logHTML += "<p> Test started at {} </p>".format(startTime) 
		log += "Test started at {}\n".format(startTime) 
		for i in range(0, requestNumber): 
			day = self.getRandomDay()
			timeSlot = self.getRandomTime() 
			event = self.getRandomEvent() 
			room = self.getRandomRoom() 
			response = requests.post(url=self.uri , json={"room" : room , "day" : day , "time": timeSlot, "event" : event})
			#print(response.status_code, response.reason, response.text)
			logHTML += "<p> {} 		status: {} {}, reply: {}</p>".format(time.time(), response.status_code, response.reason, response.text)
			log += "{} status: {} {}, reply: {}\n".format(time.time(), response.status_code, response.reason, response.text)
			## random delay between request
			randomDelay = random.randint(0,10)
			print(response) 
			#time.sleep(randomDelay) 
		
		endTime = time.time()
		logHTML += "<p> Test finished at {} </p>".format(endTime)
		log+="Test finished at {}\n".format(endTime)
		totalTime = endTime - startTime 
		logHTML += "<p> Test took {} to complete! </p>".format(totalTime)
		log+="Test took {} to complete!".format(totalTime)
		print(log)
		return (logHTML)
		



def test(requestNumber):
	client = Client() 
	return client.testMode(requestNumber)	

def main():
	client = Client() 
	print(client.testMode(10))
		
if __name__ == "__main__":
	main() 
		
		

