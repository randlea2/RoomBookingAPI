## Running API 

virtualenv venv
source venv/bin/activate
pip install flask flask-jsonpify flask-sqlalchemy flask-restful
pip freeze





## Client
enter http://127.0.0.1:5000/ into browser 
