import requests


class Client():
	
	def __init__(self):
		## base uri for the API 
		self.uri = "http://127.0.0.1:5000/timetable" 
	

	def bookRoom(self):
		## make all characters upper case & remove whitespace
		room = raw_input("What room would you like to book? L221, CG04, T101\n").strip().upper()
		
		## capitalize only first letter & remove whitespace
		day = raw_input("What day would you like to book? Mon - Fri\n")
		day = day[0].strip().upper() + day[1:].strip().lower()
		
		time = raw_input("What time would you like to book? 08:00 - 17:00\n").strip()
		
		## capitalize only first letter & remove whitespace
		event = raw_input("What is the event? Lab, Lecture etc \n")
		event = event[0].strip().upper() + event[1:].strip().lower()

		print(room,day, time, event) 
		response = requests.post(url=self.uri + "/book", json={"room" : room , "day" : day , "time": time, "event" : event})
		print(response.status_code, response.reason, response.text)
		return (response.status_code, response.reason, response.text)
		
		

def main():
	client = Client() 
	client.bookRoom() 
		
if __name__ == "__main__":
	main() 
		
		

