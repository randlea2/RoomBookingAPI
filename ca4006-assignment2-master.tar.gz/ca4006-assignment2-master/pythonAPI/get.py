import requests
## this will show the difference between the response the command line recieves vs browser
## there should be no html in this response 


def main():
	response = requests.post("http://127.0.0.1:5000/timetable/room/add", data={"name": "hi bob"})
	print(response.status_code, response.reason, response.text)
	
	
	
if __name__ == "__main__":
	main() 
