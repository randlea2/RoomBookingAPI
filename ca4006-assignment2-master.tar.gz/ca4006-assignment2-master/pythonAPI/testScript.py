

## test to run 100 get request at once 
def test1()
