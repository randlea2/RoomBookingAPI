class Event():
	
	def __init__(self, name, capacity):
		self.name  = name
		self.capacity 	= capacity
	
	def getName(self):
		return self.name
		
	def getCapacity(self):
		return self.capacity 
	
