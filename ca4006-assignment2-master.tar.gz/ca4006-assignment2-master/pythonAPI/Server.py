## imported modules
from flask import Flask, jsonify, request, render_template, redirect, abort, url_for
## import testing function from testMode.py 
from testMode import test
## import database module 
import sqlite3


## API framework 
app = Flask(__name__)




class Event():
	
	def __init__(self, name, capacity):
		self.name  = name
		self.capacity 	= capacity
	
	def getName(self):
		return self.name
		
	def getCapacity(self):
		return self.capacity 
	

		

		
class Room(): 	
	def __init__(self, name, capacity):
		self.name  = name
		self.capacity 	= capacity
	
	def getName(self):
		return self.name
		
	def getCapacity(self):
		return self.capacity 


class Timetable():
	
	@staticmethod
	def getDays(): 
		return ["Mon","Tues","Wed","Thurs","Fri"]; 
	
	@staticmethod
	def getTimeSlots():
		return ["08:00","09:00","10:00" , "11:00","12:00" , "13:00", "14:00","15:00" ,"16:00" ,"17:00"]
	
	@staticmethod
	def getRooms():
		rooms = [] 
		with sqlite3.connect('booking.db') as connection:
			cursor = connection.cursor()
			result = cursor.execute("SELECT * FROM rooms").fetchall()
			print(result) 
			for room in result:
				currentRoom = Room(room[0],room[1]) 
				rooms.append(currentRoom) 
			return rooms
	
	@staticmethod
	def createTimetable(room):
		## initialize timetable 
		dic = {} 
		days = Timetable.getDays() 
		timeSlots = Timetable.getTimeSlots() 
		## create the room list with all the rooms in roomFile.txt
		## no events at the start 
		with sqlite3.connect('booking.db') as connection:
			cursor = connection.cursor()
			result = cursor.execute("SELECT * FROM timetable WHERE name = ?",(room,)).fetchone() 
			print(result) 
			i = 1
			for day in days:
				dic[day] = {} 
				for time in timeSlots:
					dic[day][time] = result[i].split()[timeSlots.index(time)] 
					print(day,time) 
				i+=1	

		return dic 




class API():
	
	def __init__(self):
		app.run(host="127.0.0.1", port = "5000", debug = True, threaded=True)
		
		
	@app.route("/", methods = ["GET", "POST"])
	def displayTimetable():
		if request.method == "POST":
			option = request.values.get('redirect')
			print(option) 
			if (option == "roomTimetable"):
				return redirect("/timetable/room")
			elif (option == "availability"):
				return redirect("/timetable/available")
			elif (option == "testMode"):
				return redirect("/timetable/admin/test/mode") 
			elif (option == "roomList"):
				return redirect("/timetable/rooms") 
			elif (option == "errorHandling"):
				return redirect("/timetable/admin/test/error")  
			elif (option == "addRoom"):
				return redirect("/timetable/room/add")  
			else:
				return redirect("/timetable/book")
		else:
			return render_template("index.html")
	
	## error handling
	## not found
	@app.errorhandler(404)
	def pageNotFound(page):
		uriList = []
		for rule in app.url_map.iter_rules():
			if ":" not in rule.rule:
				uriList.append(rule.rule)
		return render_template('404.html', uriList = uriList), 404	
	

	## server fault 
	@app.errorhandler(500)
	def overload(page):
		return render_template('500.html'), 500	
		
	## bad request
	@app.errorhandler(400)
	def pageNotFound(page):
		return render_template('400.html'), 400
		
	@app.route("/timetable/room", methods = ["POST", "GET"])
	def roomTimetable():
		if request.method == "POST":
				roomNumber = request.values.get('room')
				return render_template("template.html",  timetable = Timetable.createTimetable(roomNumber), roomNumber = roomNumber, timeSlots= Timetable.getTimeSlots(), days = Timetable.getDays())	
		else:
				return render_template("room.html", roomNames = Timetable.getRooms()) 		

	@app.route("/timetable/book", methods = [ "POST","GET", "PUT"])
	def bookRoom():
		if (request.method == "POST"):
			## check if form data or json 
			if (request.get_json() == None):
				room = request.values.get('room')
				time = request.values.get('time')
				day = request.values.get('day')
				event =  request.values.get('event')
				with sqlite3.connect('booking.db') as connection:
					cursor = connection.cursor()
					result = cursor.execute("SELECT * FROM timetable WHERE name = ?", (room,)).fetchone() 
					timeIndex = Timetable.getTimeSlots().index(time) 
					dayIndex = Timetable.getDays().index(day) + 1
					currentDayEvents = result[dayIndex].split()
					currentEvent = currentDayEvents[timeIndex] 
					if (currentEvent == "Free"):
						currentDayEvents[timeIndex] = event 
						updateQuery = 'UPDATE timetable SET {} = ? WHERE name = ?'.format(day) 
						StrDayEvents = " ".join(currentDayEvents)
						cursor.execute(updateQuery,(StrDayEvents, room))
						check = cursor.execute("SELECT * FROM timetable WHERE name = ?",(room,)).fetchall()
						print(check) 
						return "Room {} has been booked for {} on {} at {}".format(room,event, day, time)
					else:
						return "Room {} is not available on {} at {}".format(room,day, time) 
			else:
				bookingDetails = request.get_json()
				## get the booking information from json passed to server 
				room = bookingDetails["room"]
				day = bookingDetails["day"]
				time = bookingDetails["time"] 
				event = bookingDetails["event"] 
				with sqlite3.connect('booking.db') as connection:
					cursor = connection.cursor()
					result = cursor.execute("SELECT * FROM timetable WHERE name = ?", (room,)).fetchone() 
					timeIndex = Timetable.getTimeSlots().index(time) 
					dayIndex = Timetable.getDays().index(day) + 1
					currentDayEvents = result[dayIndex].split()
					currentEvent = currentDayEvents[timeIndex] 
					if (currentEvent == "Free"):
						currentDayEvents[timeIndex] = event 
						updateQuery = 'UPDATE timetable SET {} = ? WHERE name = ?'.format(day) 
						StrDayEvents = " ".join(currentDayEvents)
						cursor.execute(updateQuery,(StrDayEvents, room))
						check = cursor.execute("SELECT * FROM timetable WHERE name = ?",(room,)).fetchall()
						print(check) 
						return "Room {} has been booked for {} on {} at {}".format(room,event, day, time)
					else:
						return "Room {} is not available on {} at {}".format(room,day, time) 
		else:
			return render_template("book.html", timeSlots = Timetable.getTimeSlots(), days = Timetable.getDays(), rooms = Timetable.getRooms())
				
	@app.route('/timetable/available', methods=["GET", 'POST'])
	def index():
		if request.method == 'POST':
			## get form data
			room = request.values.get('room')
			time = request.values.get('time')
			day = request.values.get('day')
			timeSlot = Timetable.createTimetable(room)[day][time] 
			## check if time slot is free or not
			if (timeSlot == "Free"):
				return "<h2> Result: Available  </h2> {} is available for {} at {}".format(room, day, time)
			else:
				return "<h2> Result: Not available </h2> {} has event: {} on {} at {}".format(room, timeSlot, day, time)			
		elif request.method == "GET":
			return render_template("available.html", timeSlots = Timetable.getTimeSlots(), days = Timetable.getDays(), rooms = Timetable.getRooms())
	
	@app.route("/timetable/rooms", methods = ["GET"])
	def rooms():
		roomList = [] 
		with sqlite3.connect('booking.db') as connection:
			cursor = connection.cursor()
			result = cursor.execute("SELECT * FROM rooms").fetchall()
			print(result) 
			for room in result:
				roomList.append(room)
		return render_template("roomList.html", roomList = roomList) 
		

	@app.route("/timetable/room/add", methods = ["GET", "POST"])
	def addRoom():
		if (request.method == "POST"):
			try:
				## get room number from form
				name = request.values.get('name')
				capacity = int(request.values.get('capacity'))
				with sqlite3.connect('booking.db') as connection:
					cursor = connection.cursor()
					## check if room already exist 
					check = cursor.execute("SELECT * FROM rooms WHERE name = ?",(name,)).fetchone()
					print(check) 
					if check != None:
						return "Room {} already exist....".format(name) 
					else:
						## initialize the timetable to be free
						defaultTimetable = "Free " * 10 
						cursor.execute(''' INSERT OR IGNORE INTO  rooms VALUES(?, ?)''', (name,capacity,))
						cursor.execute(''' INSERT OR IGNORE INTO  timetable VALUES(?, ?,?, ?, ? ,?)''', (name,defaultTimetable, defaultTimetable, defaultTimetable, defaultTimetable,defaultTimetable))
						result = cursor.execute("SELECT * FROM timetable").fetchall()
						return "Room: {} Successfully added!".format(name) 
			except Exception as e:
				if (e.__class__.__name__) == "ValueError":
					return "Please enter a number...." 
				else:
					return "Somethings went wrong, please try again...."
		else:
			return render_template("addRoom.html") 

	@app.route("/timetable/room/<string:roomNumber>",methods = ["GET"])
	def fetchRoom(roomNumber):
		## testing purposes may or may not be used
		## different response depending which user agent is requesting data e.g browser, command line
		if ("python" in str(request.user_agent)):
			return jsonify(timetable[roomNumber])
		else:
			return render_template("template.html",  timetable = Timetable.createTimetable(roomNumber), timeSlots= Timetable.getTimeSlots(), days = Timetable.getDays())
		
	@app.route("/timetable/<string:roomNumber>&<string:day>&<string:time>", methods = ["GET"])
	def checkTimetable(roomNumber, day, time):
		## check the availabilty of a room 
		timeSlot = Timetable.createTimetable(roomNumber)[day][time] 
		if (timeSlot == "Free"):
			return "<h2> Result </h2> {} is available for {} at {}".format(roomNumber, day, time)
		else:
			return "<h2> Result </h2> {} has event: {} on {} at {}".format(roomNumber, timeSlot, day, time)


	
	@app.route("/timetable/admin/test/mode", methods = ["GET", "POST"])
	def run():
		if (request.method == "POST"):
			## try except if a number not entered
			try:
				## get number of request from user
				requestNumber = int(request.values.get('requestNumber'))
				## call the test function from imported testMode.py
				return test(requestNumber) 
			except Exception as e:
				return "Please enter a number...."
		else:
			return render_template("test.html") 
			
	@app.route("/timetable/admin/test/error", methods = ["GET", "POST"])
	def generateError():
		if (request.method == "POST"):
			## get error number from form
			errorNumber = int(request.values.get('errorChoice'))
			abort(errorNumber)
		else:
			return render_template("error.html") 
			









		




if __name__ == "__main__":
	## Create database tables if not exist 
	connection = sqlite3.connect('booking.db')
	cursor = connection.cursor()
	cursor.execute('''CREATE TABLE IF NOT EXISTS  rooms (
					  name PRIMARY KEY,
					  capacity INTEGER DEFAULT 0)''')
	cursor.execute('''CREATE TABLE IF NOT EXISTS  timetable (
					  name PRIMARY KEY,
					  Mon text,
					  Tues text,
					  Wed text,
					  Thurs text,
					  Fri text )''')
	connection.close() 
	## Start API 
	API()
