package test;


public class Room{

	private String name;
	private String capacity;
	
	public Room(String name, String capacity){
		this.name = name;
		this.capacity = capacity;
		System.out.println(this); 
	}
	
	public String getNumber(){
		
		return this.name;
	
	}
	
	
	public String getCapacity(){
		
		return this.capacity;
	
	}


	public String toString(){
		String roomDetails = String.format("Room: %s with capacity %s", this.name, this.capacity); 
		return roomDetails; 
	}




}

