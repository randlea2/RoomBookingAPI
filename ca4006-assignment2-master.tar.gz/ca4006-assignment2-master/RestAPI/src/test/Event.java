package test;

//this class will allow an event to be created with a name and capacity 

public class Event{
	
	private String name;
	private int capacity; 
	
	public Event(String name, int capacity){
		
		this.name = name;
		this.capacity = capacity; 
		
	}

	public String getName(){
		
		return this.name;
	
	}
	
	
	public int getCapacity(){
		
		return this.capacity;
	
	}


	public String toString(){
		String eventDetails = String.format("Event: %s with capacity %d", this.name, this.capacity); 
		return eventDetails; 
	}







} 
