package test;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.Consumes;
import javax.ws.rs.core.Application;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.GET;
import javax.ws.rs.POST;

@Path("/book")
public class Hello {

	private Timetable timetable;
	private Room[] rooms = new Room[3];
	
	



	
	

	
	/*@GET
	@Produces(MediaType.TEXT_HTML)
	public String sayHelloHTML() 
	{
		String resource="<h1>hi need this is from htm</h1>";
		return resource;
	}*/
	
	
	@POST
	@Path("/booking")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	public String bookRoom(@QueryParam("roomNumber") String roomNumber, @QueryParam("day") String day, @QueryParam("time") String time) {


		
		timetable.updateSlot(roomNumber, day, time, new Event("testing",100));
		return "Timetable updated successfully!";
		
	

		
	}
	
	

	@GET
	@Path("/timetable")
	@Produces(MediaType.TEXT_PLAIN)
	public String displayTimetable(@QueryParam("roomNumber") String roomNumber) {

		rooms[0] = new Room("L221", "50"); 
		rooms[1] = new Room("T101", "400"); 
		rooms[2] = new Room("CG04", "40"); 
		timetable = new Timetable(rooms); 
		


		timetable.updateSlot("CG04", "Mon", "10:00", new Event("Lecture",100));
		timetable.updateSlot("CG04", "Mon", "12:00", new Event("Lab",100));
		timetable.updateSlot("CG04", "Thurs", "10:00", new Event("Lecture",100));
		timetable.updateSlot("CG04", "Fri", "12:00", new Event("Lab",100));
		timetable.updateSlot("CG04", "Fri", "14:00", new Event("Lab",100));

		
		
		
		
		return 	timetable.displayRoomTimetable(roomNumber);

		
	}

	
	/*@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String bookRoom(@QueryParam("roomNumber") String roomNumber, @QueryParam("day") String day, @QueryParam("time") String time, @QueryParam("event") String event) {


	
		timetable.updateSlot("roomNumber", "day", "time", new Event(event,100));
		return "Timetable updated successfully!";
		
	

		
	}*/
}
