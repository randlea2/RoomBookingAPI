package test;

import java.util.*; 
import java.util.Date;
import java.text.*; 
import java.util.Calendar;
import java.util.Date;
import java.time.*; 
// Import the HashMap class
import java.util.HashMap;
public class Timetable{
	
	// class variables
	private HashMap<String, HashMap<String, HashMap<String, Event>>> timetable;
	private Room[] rooms; 
	
	
	public Timetable(Room[] rooms ){
		
		// initialize the room list to all the rooms passed to it 
		this.rooms = rooms; 
		// create timetable
		this.timetable = createTimetable(); 


		
	}
	
	// this will return a list of all the timeslots between 8:00 and 18:00 in half an hour increments
	public String[] timeSlots(){
		String[] slots = new String[10]; 
		LocalTime localTime =  LocalTime.of(8, 00);
		
		for(int i=0;i<10;i++){			
			slots[i] = localTime.toString(); 		
			// go up in intervals of 30 minutes until 17:30 
			//localTime = localTime.plusMinutes(30); 
			localTime = localTime.plusHours(1); 
		}
		return slots; 
	}
	
	public String[] roomNumbers(){
		String[] roomNums = new String[rooms.length];
		
		for(int i=0;i<rooms.length; i++){
			roomNums[i]  = rooms[i].getNumber(); 
		}
		
		return roomNums; 
	}
	
	
	// return a string list containing all week day abbreviations
	public String[] shortWeekDays(){
		// includes saturday and sunday! 
		//String[] weekdays = new DateFormatSymbols().getShortWeekdays();
		
		String[] days = {"Mon","Tues","Wed","Thurs","Fri"}; 
		return days;
	}
	
	public String[] weekDays(){
		// includes saturday and sunday! 
		//String[] weekdays = new DateFormatSymbols().getWeekdays();
		
		String[] days = {"Monday","Tuesday","Wednesday","Thursday","Friday"}; 
		return days;
	}
	
	/*public String[] timeSlots(){
		String[] slots = {"08:00","09:00","10:00" , "11:00","12:00" , "13:00", "14:00","15:00" ,"16:00" ,"17:00"}; 
		return slots;           

		
	}*/
	public HashMap<String, HashMap<String, HashMap<String, Event>>> createTimetable(){
		// hashmap containing all room timetables, the room number is the key and value the rooms timetable 
		HashMap<String, HashMap<String, HashMap<String, Event>>> tmpTimetable = new HashMap<String, HashMap<String, HashMap<String, Event>>>(); 

		
		// create a timetable for each room 
		for (Room room : rooms){
			// the whole timetable maps room number to the timetable details of that room 
			// {L101 -> roomTimetable, T101 -> roomTimetable}
			// L101 roomTimetable -> {10 : "Workshop", 11: "Lecture"} 10 is 10/11, 11 is 11/12
			HashMap<String,  HashMap<String, Event>> tmpRoomTimetable = new HashMap<String,  HashMap<String, Event>>(); 
			HashMap<String, Event> tmpRoomEvents =  new HashMap<String, Event>(); 
			
			
			
			
			for (String day: shortWeekDays()){
				// no events initially 
				tmpRoomEvents =  new HashMap<String, Event>(); 
				
				for(String timeSlot : timeSlots()){
					// currently no events in timetable 
					tmpRoomEvents.put(timeSlot, null);
					// go up in intervals of 20 minutes until 17:30 
				}
				
				// put all empty rooms events into room timetable
				tmpRoomTimetable.put(day, tmpRoomEvents);
			}
				
				// put the room timetable into overall timetable 
				tmpTimetable.put(room.getNumber(), tmpRoomTimetable);

		}
			
		return tmpTimetable; 
	}
	

	
	public String displayRoomTimetable(String roomNumber){
	      HashMap<String,  HashMap<String, Event>> roomTimetable = timetable.get(roomNumber); 
	      
	      String timetable = "";
	      
	      // print heading with room number padded with *
	      String padding =  new String(new char[150]).replace("\0", "*");
	      
	      timetable+="\n" + new String(new char[102]).replace("\0", "*") + "\n";
	      
	      System.out.println(padding);
	      padding = new String(new char[70]).replace("\0", "*");
	      String heading = String.format("%-50s   %s   %50s",padding, roomNumber,padding);
	      System.out.println(heading);  
	     
	      timetable+= "\n						" + roomNumber + "								\n";

	      padding = new String(new char[150]).replace("\0", "*");
	      System.out.println(padding); 
	      
	      timetable+="\n" + new String(new char[102]).replace("\0", "*") + "\n";

	      
	      // print space to align correctly 
	      System.out.printf("%-7s", ""); 
	      timetable += String.format("%-7s", "");
	      // print time slot across top 
	      for (String timeSlot :timeSlots()){
	    	      timetable += String.format("%-10s", timeSlot);
				  System.out.printf("%-15s", timeSlot); 
			  }
		  
		  
		  
		  // print newline for days 	 
		  System.out.println();
		  timetable += "\n";
	      for (String day: shortWeekDays()){
			  //print all the events for today 
			  HashMap<String, Event> dayEvents = roomTimetable.get(day); 
			  System.out.printf("%-7s", day); 
			  timetable += String.format("\n%-7s", day);
			  for (String slot: timeSlots()){
				  Event event = dayEvents.get(slot); 
				  if(event == null){
				   timetable += String.format("%-10s", "Free");
				   System.out.printf("%-15s", "Free"); 
				  }
				  
				  else{
					   timetable += String.format("%-10s", event.getName());
					   System.out.printf("%-15s", event.getName()); 
			      }
			  }
			  timetable+="\n";
			  System.out.print("\n"); 
			 
		  }

		
		return timetable; 
		
		
		
	
	
	}



	// this will return the 7 days from now 
	public String[]  allDates(){
		String[] dates = new String[7]; 
		SimpleDateFormat dayFormat = new SimpleDateFormat( "EE" );
		SimpleDateFormat dateFormat = new SimpleDateFormat( " dd/M/yyyy" );
		Calendar cal = Calendar.getInstance();
		String date, day; 
		
		for(int i=0;i<7;i++){
			date = dateFormat.format(cal.getTime()); 
			day = dayFormat.format(cal.getTime()); 
		    dates[i] = day + date; 
		    cal.add( Calendar.DATE, 1 );

		}
		
		return dates; 
		
	}
	
	
	// returns true if can hold capacity 
	// otherwise false 
	public boolean checkCapacity(String roomNumber, int eventCapacity){
		Room thisRoom; 
		
		for (Room room : rooms){
			
		    if((room.getNumber().equals(roomNumber))){
				
				int roomCapacity = Integer.parseInt(room.getCapacity());
				if(roomCapacity > eventCapacity){
					return true;
				}
				
				else{
					return false; 
				}
			}
		}
		
		return true; 
		
	}
	
	
	
	// this will return the event at a slot or null if no event 
	public Event checkSlot(String roomNumber, String day, String time){
		
		
		// return what event is on for that time 
		// if free, return null 
		try{
		    
		    // get the whole timetaable for that room 
			HashMap<String,  HashMap<String, Event>> tmpRoomTimetable = timetable.get(roomNumber); 
			// get the events for that day 
			HashMap<String, Event> tmpRoomEvents =  tmpRoomTimetable.get(day); 
			// get the event on at that time 
			Event event =  tmpRoomEvents.get(time); 
			
			return event; 
			
			
		}
		
		// incorrect details entered
		catch(Exception e){
			  e.printStackTrace(); 
			  System.out.println("The specified timetable cannot be found"); 
			  return null; 
		}
		


	}
	
	
	// this will return the event at a slot or null if no event 
	public void updateSlot(String roomNumber, String day, String time, Event event){
		
		
		// update the corresponding slot with the event passed in 
		try{
		    
		    
		    // check if theres an event on in that slot
		    Event slotEvent =  checkSlot(roomNumber, day, time); 
			
			// no event in slot
			if (slotEvent == null){
					
					// update the slot event 
					timetable.get(roomNumber).get(day).replace(time, event); 
					System.out.println("Event added successfully!"); 

			}
			
			
			
			else{
				// if there is already an event on at that time 
				System.out.println("Slot is full!"); 
			} 
			
			
		}
		
		// incorrect details entered
		catch(Exception e){
			  e.printStackTrace(); 
			  System.out.println("The specified timetable cannot be found"); 
		}
		


	}
	
	
	
	public void bookRoom(){
		
		 // initialize scanner object 
	     Scanner scanner = new Scanner(System.in);  
		
		// first get room they'd like to book 
		System.out.println("What room would you like to book? " + String.join(" ", roomNumbers()));
		String roomNumber = scanner.nextLine().toUpperCase();  // capitalize for easier matching 
		
		
		// incorrect room number entered
		while(!(Arrays.asList(roomNumbers()).contains(roomNumber)))
		{
			System.out.println("Incorrect room number entered!");
			System.out.println("What room would you like to book? " + String.join(" ", roomNumbers()));
			roomNumber = scanner.nextLine().toUpperCase();
			
		}
		
		// map "Mon" -> "Monday" incase they use abbreviations 
		Map<String, String> allDays = new HashMap<String, String>();
		for (int i=0;i<5;i++){
			allDays.put(weekDays()[i], shortWeekDays()[i]); 
		}
		
		
		// then find out the day they'd like to book 
		System.out.println("What day would you like to book? ");
		String day = scanner.nextLine().replaceAll("\\s+", ""); //  read input and remove whitespace
		day = day.substring(0, 1).toUpperCase() +  day.substring(1).toLowerCase();
	
		
		// get the abbreviation if they use full day name e.g if they enter monday , day = "MON" 
		if(allDays.containsKey(day)){
			day = allDays.get(day);
		}
		
		// incorrect day entered
		while(!(Arrays.asList(shortWeekDays()).contains(day))){
			System.out.println("Incorrect day entered try again!");
			System.out.println("What day would you like to book? ");
		    day = scanner.nextLine().replaceAll("\\s+", "");;  //  read input and remove whitespace
		    day = day.substring(0, 1).toUpperCase() +  day.substring(1).toLowerCase();
		    if(allDays.containsKey(day)){
				day = allDays.get(day);
			}
		}

		
		
		
		
	    // find out the booking time 
		System.out.println("What time would you like to book? 09:00 - 17:00 ");
		String time = scanner.nextLine().toUpperCase();  // read input 
		
		// if incorrect time not entered 
		while(!(Arrays.asList(timeSlots()).contains(time))){
			System.out.println("Incorrect time entered try again!");
			System.out.println("What time would you like to book? 09:00 - 17:00 ");
			time = scanner.nextLine().toUpperCase(); 
		}
		
		//  what the event is 
	    System.out.println("What event is being held? Lab, Lecture etc ");
	    String eventName = scanner.nextLine().replaceAll("\\s+", ""); // read name and remove whitespace 
	    eventName = eventName.substring(0, 1).toUpperCase() +  eventName.substring(1).toLowerCase(); // format with first letter capital and rest lower e.g lab -> Lab
		
        // capacity of the event 
        System.out.println("How many people will be there? ");
	    int eventCapacity = scanner.nextInt(); // read integer 
	    
	    
	    // the room will not hold this capacity 
		if(checkCapacity(roomNumber, eventCapacity) == false){
			System.out.printf("%s will not hold that many people!\n", roomNumber); 
			bookRoom(); // start process again
		}
		
		
		
		// create event with name  
		Event event = new Event(eventName,eventCapacity); 
		
		// update the slot 
		updateSlot(roomNumber, day, time, event); 

		
		
		
		//display timetable to show updates
		displayRoomTimetable(roomNumber); 
		
		
	}










}
